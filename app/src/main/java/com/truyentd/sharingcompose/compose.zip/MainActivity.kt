package com.truyentd.sharingcompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.truyentd.sharingcompose.recomposition.RecompositionExample
import com.truyentd.sharingcompose.ui.theme.SharingComposeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SharingComposeTheme {
                RecompositionExample()
            }
        }
    }
}
